# health-bar-detection > Roboflow Instant 1 [Eval]
https://universe.roboflow.com/fall-zx3tu/health-bar-detection

Provided by a Roboflow user
License: CC BY 4.0

